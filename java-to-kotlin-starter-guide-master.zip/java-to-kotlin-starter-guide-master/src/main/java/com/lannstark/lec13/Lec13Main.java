package com.lannstark.lec13;

public class Lec13Main {

  public static void main(String[] args) {

  }

}
