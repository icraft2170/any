package com.lannstark.lec15;

public class Lec15Main {

  public static void main(String[] args) {
  }

}
