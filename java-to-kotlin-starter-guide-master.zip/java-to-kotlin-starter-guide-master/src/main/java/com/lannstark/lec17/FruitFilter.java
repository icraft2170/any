package com.lannstark.lec17;

public interface FruitFilter {

  boolean isSelected(Fruit fruit);

}

