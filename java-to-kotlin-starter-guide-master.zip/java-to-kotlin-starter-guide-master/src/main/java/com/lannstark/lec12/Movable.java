package com.lannstark.lec12;

public interface Movable {

  void move();

  void fly();

}
