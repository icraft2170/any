package com.lannstark.lec09;

public class Lec09Main {

  public static void main(String[] args) {

  }

}
