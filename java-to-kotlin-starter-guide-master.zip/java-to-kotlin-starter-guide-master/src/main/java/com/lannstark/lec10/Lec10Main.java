package com.lannstark.lec10;

public class Lec10Main {

  public static void main(String[] args) {
    new JavaDerived();
  }

}
