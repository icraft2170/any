package com.lannstark.lec10;

public class JavaBase {

  public JavaBase() {
    System.out.println(getMember());
  }

  public int getMember() {
    return 1;
  }

}
