package com.lannstark.lec16;

public class Lec16Main {

  public static void main(String[] args) {

    System.out.println("Hello World");


    int number = 100;

  }

}
